import { NextFunction, Request, Response } from "express";
import { UserRole } from "../models/User";

export const registerValidator = (req: Request, res: Response, next: NextFunction) => {
  const { fullName, email, password, role } = req.body;

  if (!fullName || !email || !password || !role) {
    return res.status(400).json({ success: false, message: "Please fill in all required fields" });
  }

  if (typeof fullName !== "string" || fullName.trim().length < 3 || fullName.trim().length > 50) {
    return res.status(400).json({ success: false, message: "Full name must be a string between 3 and 50 characters long" });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (typeof email !== "string" || !emailRegex.test(email)) {
    return res.status(400).json({ success: false, message: "Please provide a valid email" });
  }

  if (typeof password !== "string" || password.length < 6) {
    return res.status(400).json({ success: false, message: "Password must be at least 6 characters" });
  }

  if (role !== UserRole.PATIENT && role !== UserRole.DOCTOR) {
    return res.status(400).json({ success: false, message: "Role must be either 'patient' or 'doctor'" });
  }

  next();
};

export const loginValidator = (req: Request, res: Response, next: NextFunction) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ success: false, message: "Email and password are required" });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (typeof email !== "string" || !emailRegex.test(email)) {
    return res.status(400).json({ success: false, message: "Please provide a valid email" });
  }

  next();
};
