import { NextFunction, Request, Response } from "express";
import jwt, { JwtPayload } from "jsonwebtoken";

export type UserRole = "patient" | "doctor" | "admin";

export interface AuthUser {
  id: string;
  role: UserRole;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

const getJwtSecret = () => process.env.JWT_SECRET || process.env.JWT_SECRET_KEY;

const normalizeRole = (role: unknown): UserRole | null => {
  if (role === "patient" || role === "doctor" || role === "admin") return role;
  if (role === "Patient") return "patient";
  if (role === "Doctor") return "doctor";
  if (role === "Admin") return "admin";
  return null;
};

interface AppJwtPayload extends JwtPayload {
  userId?: string;
  role?: string;
}

export const authenticate = (req: Request, res: Response, next: NextFunction): void => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      res.status(401).json({ success: false, message: "Authentication required" });
      return;
    }

    const token = authHeader.split(" ")[1];
    const secret = getJwtSecret();
    if (!secret) {
      res.status(500).json({ success: false, message: "JWT secret is not configured" });
      return;
    }

    const decoded = jwt.verify(token, secret) as AppJwtPayload;
    const userId = decoded.userId;
    const role = normalizeRole(decoded.role);

    if (!userId || !role) {
      res.status(401).json({ success: false, message: "Invalid token payload" });
      return;
    }

    req.user = { id: userId, role };
    next();
  } catch {
    res.status(401).json({ success: false, message: "Invalid or expired token" });
  }
};

export const authorizeRoles = (...roles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ success: false, message: "Not authorized, no token" });
      return;
    }

    if (!roles.includes(req.user.role)) {
      res.status(403).json({
        success: false,
        message: `Role '${req.user.role}' is not authorized for this action`,
      });
      return;
    }

    next();
  };
};

export const adminOnly = authorizeRoles("admin");
export const protect = authenticate;
export const authorize = authorizeRoles;
