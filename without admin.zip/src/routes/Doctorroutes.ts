import { Router } from "express";
import { getAllDoctors, getDoctorById, updateOwnProfile } from "../controllers/Doctorcontroller";
import { authenticate, authorizeRoles } from "../middleware/authMiddleware";

const router = Router();

router.get("/", getAllDoctors);
router.get("/:id", getDoctorById);
router.put("/profile", authenticate, authorizeRoles("doctor"), updateOwnProfile);

export default router;
