import { Router } from "express";
import { registerValidator, loginValidator } from "../validators/authValidators";
import { authenticate } from "../middleware/authMiddleware";
import { registerUser, loginUser, getCurrentUser } from "../controllers/authController";

const router = Router();

router.post("/register", registerValidator, registerUser);
router.post("/login", loginValidator, loginUser);
router.get("/current-user", authenticate, getCurrentUser);

export default router;
