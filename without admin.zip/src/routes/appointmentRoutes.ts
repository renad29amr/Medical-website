import { Router } from "express";
import appointmentController from "../controllers/appointmentController";
import { validateCreateAppointment } from "../validators/appointmentValidator";
import { authenticate, authorizeRoles } from "../middleware/authMiddleware";

const router = Router();

router.post("/", authenticate, authorizeRoles("patient"), validateCreateAppointment, appointmentController.createAppointment);
router.get("/my", authenticate, authorizeRoles("patient"), appointmentController.getAppointments);
router.get("/doctor", authenticate, authorizeRoles("doctor"), appointmentController.getDoctorAppointments);
router.patch("/:id/confirm", authenticate, authorizeRoles("doctor"), appointmentController.confirmAppointment);
router.patch("/:id/complete", authenticate, authorizeRoles("doctor"), appointmentController.completeAppointment);
router.patch("/:id/cancel", authenticate, authorizeRoles("patient", "doctor"), appointmentController.cancelAppointment);

export default router;
