import { Router } from "express";
import { createSchedule, getAllSchedules, updateSchedule, deleteSchedule } from "../controllers/Schedulecontroller";
import { authenticate, authorizeRoles } from "../middleware/authMiddleware";

const router = Router();

router.get("/", authenticate, getAllSchedules);
router.post("/", authenticate, authorizeRoles("doctor"), createSchedule);
router.put("/:id", authenticate, authorizeRoles("doctor"), updateSchedule);
router.delete("/:id", authenticate, authorizeRoles("doctor"), deleteSchedule);

export default router;
